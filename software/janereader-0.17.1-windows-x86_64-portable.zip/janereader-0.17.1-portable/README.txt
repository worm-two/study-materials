# Some Notes on the Portable Version:

  1. The portable version does not require installation;
  2. The data of the portable version is stored in the janereader-data directory under the same directory as the executable file;
  3. Jane Reader relies on webview2 to run. If you cannot run Jane Reader, please first try installing webview2. You can download and install webview2 from the following website: https://developer.microsoft.com/microsoft-edge/webview2/. If you are using third-party software to block webview2 (such as Edge Blocker), please unblock webview2;

# How to Migrate Data from the Installation Version to the Portable Version?

The portable version's data is stored in the janereader-data\data directory within the same directory as the application. Data of the installation version is stored in the C:\Users\[Your Username]\AppData\Local\com.janereader.janereader directory. You just need to copy all the items in the corresponding directory over.

The portable version's settings are stored in the janereader-data\config directory within the same directory as the application. The installation version's settings are stored in the C:\Users[Your Username]\AppData\Roaming\com.janereader.janereader directory. To transfer settings, simply copy the 'config.json' file from the corresponding directory.

Both the portable and installation versions share the '.window-state.json' file located in 'C:\Users[Your Username]\AppData\Roaming\com.janereader.janereader', which records window size and position. This file does not need to be copied.

Note: To avoid damaging your data, please complete these steps right before migration:

  1. Fully exit the Jane Reader program;
  2. Back up your data;
