# 关于便携版的一些说明：

  1. 便携版无需安装；
  2. 便携版的数据存放在与可执行文件同一目录下的 janereader-data 目录中；
  3. Jane Reader 依赖于 webview2 才能运行；如果您无法运行 Jane Reader, 请首先尝试安装 webview2. 您可以从以下网址下载安装 webview2: https://developer.microsoft.com/microsoft-edge/webview2/; 如果您使用第三方软件屏蔽了 webview2 (比如 Edge Blocker), 请解除对 webview2 的屏蔽；

# 如何将数据从安装版迁移到便携版？

便携版的数据存放于同一目录下的 janereader-data\data\ 目录中，安装版的数据存放于 C:\Users\[您的用户名]\AppData\Local\com.janereader.janereader\ 目录中，只需将对应目录下的所有项目拷贝过来即可。

便携版的设置存放于同一目录下的 janereader-data\config\ 目录中，安装版的设置存放于 C:\Users\[您的用户名]\AppData\Roaming\com.janereader.janereader 目录中，只需要将对应目录下的 config.json 文件拷贝过来即可。

便携版和安装版共用 C:\Users\[您的用户名]\AppData\Roaming\com.janereader.janereader 目录中的 .window-state.json 文件记录窗口大小和位置，这个文件不需要拷贝。

注意：为了避免损坏数据，在迁移数据之前，请：

  1. 完全退出 Jane Reader 程序；
  2. 备份您的数据；
